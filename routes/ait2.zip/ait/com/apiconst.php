<?php
/*--------------------------------------------------------------------------
 * Copyright (C) 2017 Apical Innovations- All Rights Reserved
 * You shall use, but not distribute and modify this code under the
 * terms of the license,
 *-------------------------------------------------------------------------*/

define('P6', 'AAAAgOEtX5k:APA91bGaJOxFYka2C1lUShMtfObtkAciDia-t5xNRrD1ym5l_TbGOZC-Z61q9LY19nW-twYb9CzN_gQarOJ4lykU7rxLi1KftETq1kjtSMBLo2fXRz5kkORdO2K1CzAumN2WXeXZFvSr');

define('P1','localhost');
define('P2','timesqure');
define('P5','https://fcm.googleapis.com/fcm/send');
define('P3','pmp_admin');
define('P4','Mdex@2312');

define('P8','FieldView Ai-Assistant');
define('P9','  is nearby, you may visit !!!');
define('P10',' has raised Service Call in ');
define('P11',' has Requsted Quote for ');

define('P12','smtp.gmail.com');
define('P13','contact@apicalin.com');
define('P14','Mdex@2312');
define('P15','Team Apical');

define('P33','http://172.104.17.202/lms/ts_webservices/');
define('P34','contents/');
define('P99','AIzaSyDF10bqtikHgZBwjP1bGvN8Y3W2OcK6YNA');

