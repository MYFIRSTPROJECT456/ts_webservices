<?php
require_once dirname(__FILE__) . '/../com/apicalbe.php';
require_once dirname(__FILE__) . '/../com/apicaldb.php';
require      dirname(__FILE__) . '/../vendor/autoload.php';
require_once dirname(__FILE__) . '/../com/apiconst.php';
require_once dirname(__FILE__) . '/../com/apicalul.php';

  $Qry = " SELECT notify_id, date_gen,senderid, (SELECT GROUP_CONCAT(tbl_login.fcmid) from tbl_login WHERE FIND_IN_SET(2,REPLACE(receiverid,' ',''))) as fcmids,receiverid, reftxnid as tktid ,fcmid, title, notify_type, notify_url, click_action, msg, data,  date_format(date_gen,'%m/%d/%Y') as date_gen,(SELECT username FROM tbl_users WHERE uid=senderid) as sender FROM `tbl_notifications` WHERE status = 0 ORDER by 2 DESC LIMIT 5";
    $response = executesel($Qry);
    foreach ($resnpose as $record)
    {
      $response = sendv1($record["fcmids"], $record["msg"], $record["title"], 1,$record["notify_type"],$record["notify_url"],$record["click_action"],$record["date_gen"]);
    }
?>
